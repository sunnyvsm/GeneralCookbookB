#tomcat installation

directory '/warfiles' do
owner 'root'
group 'root'
mode 777
action :create
not_if 'find /warfiles'
end

remote_file "#{Chef::Config['file_cache_path']}/apache-tomcat-8.0.32.zip" do
source 'http://a.mbbsindia.com/tomcat/tomcat-8/v8.0.32/bin/apache-tomcat-8.0.32.zip'
owner 'root'
group 'root'
end

bash 'insatlling tomcat8' do
cwd '/tmp'
code <<-EOH
unzip apache-tomcat-8.0.32.zip
EOH
not_if 'find /tmp/apache-tomcat-8.0.32'
end


template '/tmp/apache-tomcat-8.0.32/conf/tomcat-users.xml' do
source 'tomcat-users.xml.erb'
user 'root'
group 'root'
mode '0644'
end

bash 'start tomcat' do
cwd '/tmp/apache-tomcat-8.0.32'
code <<-EOH
chmod -R  +x /tmp/apache-tomcat-8.0.32/bin/*
/tmp/apache-tomcat-8.0.32/bin/startup.sh
EOH
end

execute 'StopOldWar' do
       command 'wget --http-user=admin --http-password=password http://52.36.167.196/manager/text/stop?path=/webapp1'
        action :run
		only_if 'find /tmp/apache-tomcat-8.0.32/webapp1'
   end
execute 'UnDeployOldWar' do
       command 'wget --http-user=admin --http-password=password http://52.36.167.196/manager/text/undeploy?path=/webapp1'
       action :run
	   only_if 'curl http://52.36.167.196/webapp1 | grep Error'
	   end
execute 'DeployNewWar' do
       command 'wget --http-user=admin --http-password=password "http://52.36.167.196/manager/text/deploy?war=file:/warfiles/webapp1.war&path=/webapp1"'
       action :run
end

   
   
    execute ‘StopOldWar’ do
        command ‘wget –http-user=admin –http-password=password “http://tomcat7-dev:8080/manager/text/stop?path=/webapp1″ -O -‘
        action :run
   end

