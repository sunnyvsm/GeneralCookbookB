﻿
/* ==============================================================================

    APPLICATION LEVEL SETUP
    Contains application level logic

 ============================================================================= */


/*
    Main Application Namespace
*/
var app = {};

