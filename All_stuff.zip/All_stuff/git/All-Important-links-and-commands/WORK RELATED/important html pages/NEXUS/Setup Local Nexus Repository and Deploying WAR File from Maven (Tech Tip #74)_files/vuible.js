function ipin(){
var ipinsite='Good%20Vibes.%20Vuible.com';
var ipinsiteurl='http://vuible.com/';
(function(){
var ipinsite='Good%20Vibes.%20Vuible.com';
var ipinsiteurl='http://vuible.com/';

if(window.ipinit!==undefined){ipinit();}else{document.body.appendChild(document.createElement('script')).src='http://vuible.com/wp-content/themes/ipinpro/js/ipinit.js';}})();

}