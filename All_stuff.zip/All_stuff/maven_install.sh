#!/bin/bash
#maven installer
cd /home/ec2-user
wget http://www.us.apache.org/dist/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz
sudo tar -xzvf apache-maven-3.3.9-bin.tar.gz -c /opt

vi ~/.bashrc

export MAVEN_HOME=/opt/apache-maven-3.3.9
export M2_HOME=/opt/apache-maven-3.3.9
export M2=/opt/apache-maven-3.3.9
export PATH=/opt/apache-maven-3.3.9:$PATH

source ~/.bashrc

mvn -version

/opt/apache-maven-3.3.9/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/opt/aws/bin:/root/bin