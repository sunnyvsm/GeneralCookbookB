default['aig_sqlserver']['pckg_path'] = "C:\\en_sql_server_2008_r2_developer_x86_x64_ia64_dvd_522665"
default['aig_sqlserver']['strt_typ'] = "Automatic"
default['aig_sqlserver']['action'] = "Install"
default['aig_sqlserver']['features'] = "SQLENGINE,REPLICATION,FULLTEXT,CONN,IS,SDK,BOL,SSMS,ADV_SSMS,SNAC_SDK,OCS"

default['aig_sqlserver']['help'] = "FALSE"
default['aig_sqlserver']['security_mode'] = "SQL"
default['aig_sqlserver']['inst_id'] = "SQLPCDNPM101"
default['aig_sqlserver']['inst_nm'] = "#{node['aig_sqlserver']['inst_id']}"
default['aig_sqlserver']['install_dir'] = 'C:\Program Files\Microsoft SQL Server'
default['aig_sqlserver']['prog'] = "True"

#credentials
default['aig_sqlserver']['sql_srvr_agt_srv']['usrnm']= 'NT AUTHORITY\SYSTEM'
 default['aig_sqlserver']['sql_srvr_agt_srv']['strt_typ']= "#{node['aig_sqlserver']['strt_typ']}"
 
 default['aig_sqlserver']['sql_srvr_srvc']['account'] = 'NT AUTHORITY\SYSTEM'
 default['aig_sqlserver']['sql_srvr_srvc']['strt_typ'] = "#{node['aig_sqlserver']['strt_typ']}"
 
 default['aig_sqlserver']['intgrt_srvc']['account'] = 'NT AUTHORITY\NetworkService'
 default['aig_sqlserver']['intgrt_srvc']['strt_typ'] = "#{node['aig_sqlserver']['strt_typ']}"
 
 default['aig_sqlserver']['anlys']['strt_typ'] = "#{node['aig_sqlserver']['strt_typ']}"
 
 default['aig_sqlserver']['sys_admn']['role'] = 'RAVI0405\arpit.kohale'
 
 default['aig_sqlserver']['ful_fltr']['account'] = 'NT AUTHORITY\LOCAL SERVICE'
 
 default['aig_sqlserver']['sql_sa']['password'] = "Password01"
 
 
 default['aig_sqlserver']['colatn'] ="Latin1_General_CI_AS"
 default['aig_sqlserver']['sql_colatn'] = "SQL_Latin1_General_CP1_CI_AS"
