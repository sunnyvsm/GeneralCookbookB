#
# Cookbook Name:: aig_sqlserver
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
execute "SQL Server Installation" do
cwd  "#{node['aig_sqlserver']['pckg_path']}"
command "Setup.exe /q 
/ACTION=#{node['aig_sqlserver']['action']} /IACCEPTSQLSERVERLICENSETERMS /FEATURES=#{node['aig_sqlserver']['features']}  /SECURITYMODE=#{node['aig_sqlserver']['securitymode']} /INSTANCEID=#{node['aig_sqlserver']['inst_id']} /INSTANCENAME=#{node['aig_sqlserver']['inst_nm']} /INDICATEPROGRESS=#{node['aig_sqlserver']['prog']} /INSTANCEDIR='#{node['aig_sqlserver']['install_dir']}' /AGTSVCACCOUNT=#{node['aig_sqlserver']['sql_srvr_agt_srv']['usrnm']} /AGTSVCSTARTUPTYPE=#{node['aig_sqlserver']['sql_srvr_agt_srv']['strt_typ']}  /SQLSVCACCOUNT=#{node['aig_sqlserver']['sql_srvr_srvc']['account']} /SQLSVCSTARTUPTYPE=#{node['aig_sqlserver']['sql_srvr_srvc']['strt_typ']} /ISSVCACCOUNT=#{node['aig_sqlserver']['intgrt_srvc']['account']} /ISSVCStartupType=#{node['aig_sqlserver']['intgrt_srvc']['strt_typ']}  /ASSVCSTARTUPTYPE=#{node['aig_sqlserver']['anlys']['strt_typ']} /SQLCOLLATION=#{node['aig_sqlserver']['sql_colatn']} /ASCOLLATION=#{node['aig_sqlserver']['colatn']} /ADDCURRENTUSERASSQLADMIN=#{node['aig_sqlserver']['help']}  /SQLSYSADMINACCOUNTS=#{node['aig_sqlserver']['sys_admn']['role']}/FTSVCACCOUNT=#{node['aig_sqlserver']['ful_fltr']['account']} /SAPWD=#{node['aig_sqlserver']['sql_sa']['password']}
end